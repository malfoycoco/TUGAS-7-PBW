<?php
include '../koneksi.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $npm     = $_POST['npm'];
    $nama    = $_POST['nama'];
    $jurusan = $_POST['jurusan'];
    $alamat  = $_POST['alamat'];

    $query = "INSERT INTO mahasiswa (npm, nama, jurusan, alamat) 
              VALUES ('$npm', '$nama', '$jurusan', '$alamat')";
    mysqli_query($conn, $query);
    header("Location: index.php");
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Tambah Mahasiswa</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>

<h1>Tambah Mahasiswa</h1>
<form method="POST">
    <label>NPM</label><br>
    <input type="text" name="npm" required><br><br>

    <label>Nama</label><br>
    <input type="text" name="nama" required><br><br>

    <label>Jurusan</label><br>
    <input type="text" name="jurusan" required><br><br>

    <label>Alamat</label><br>
    <textarea name="alamat" required></textarea><br><br>

    <button type="submit">Simpan</button>
</form>
<br>
<a href="index.php">Kembali</a>
</body>
</html>
