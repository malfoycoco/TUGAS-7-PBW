<?php
include '../koneksi.php';

$npm = $_GET['npm'];

// Hapus dulu data di tabel KRS yang terkait
mysqli_query($conn, "DELETE FROM krs WHERE mahasiswa_npm='$npm'");

// Baru hapus dari tabel mahasiswa
mysqli_query($conn, "DELETE FROM mahasiswa WHERE npm='$npm'");

header("Location: index.php");
?>

