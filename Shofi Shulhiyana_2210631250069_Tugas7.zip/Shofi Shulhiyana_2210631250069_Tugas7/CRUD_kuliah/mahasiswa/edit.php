<?php
include '../koneksi.php';
$npm = $_GET['npm'];
$query = mysqli_query($conn, "SELECT * FROM mahasiswa WHERE npm='$npm'");
$data = mysqli_fetch_assoc($query);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nama    = $_POST['nama'];
    $jurusan = $_POST['jurusan'];
    $alamat  = $_POST['alamat'];

    $update = "UPDATE mahasiswa SET nama='$nama', jurusan='$jurusan', alamat='$alamat' 
               WHERE npm='$npm'";
    mysqli_query($conn, $update);
    header("Location: index.php");
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Edit Mahasiswa</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>

<h1>Edit Mahasiswa</h1>
<form method="POST">
    <label>NPM</label><br>
    <input type="text" name="npm" value="<?= $data['npm'] ?>" disabled><br><br>

    <label>Nama</label><br>
    <input type="text" name="nama" value="<?= $data['nama'] ?>" required><br><br>

    <label>Jurusan</label><br>
    <input type="text" name="jurusan" value="<?= $data['jurusan'] ?>" required><br><br>

    <label>Alamat</label><br>
    <textarea name="alamat" required><?= $data['alamat'] ?></textarea><br><br>

    <button type="submit">Update</button>
</form>
<br>
<a href="index.php">Kembali</a>
</body>
</html>
